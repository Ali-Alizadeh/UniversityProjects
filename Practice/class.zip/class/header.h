#ifndef PERSON
#define PERSON

#include<iostream>
#include<string>
using namespace std;

struct Person {
    string name;
    int id;
};

#endif
